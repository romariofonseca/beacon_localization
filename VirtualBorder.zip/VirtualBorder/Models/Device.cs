using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;


















public class AppDbContext : DbContext
{
    public DbSet<Device> Devices { get; set; }
    public DbSet<Gateways> Gateways { get; set; }
    public DbSet<Map> Map { get; set; }
    public DbSet<RegisteredDevice> RegisteredDevice { get; set; }
    
    // Adicionando a tabela GpsData ao contexto
    public DbSet<GpsData> GpsData { get; set; }

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Mapear a entidade 'Device' para a tabela 'dispositivos'
        modelBuilder.Entity<Device>().ToTable("dispositivos");
        modelBuilder.Entity<Gateways>().ToTable("gateways");
        modelBuilder.Entity<Map>().ToTable("mapas");
        modelBuilder.Entity<RegisteredDevice>().ToTable("dispositivos_cadastrados");

        // Mapear a entidade 'GpsData' para a tabela 'gps'
        modelBuilder.Entity<GpsData>().ToTable("gps");
        modelBuilder.Entity<GpsData>().HasKey(x => x.Id);  // Chave prim�ria
        modelBuilder.Entity<GpsData>().Property(x => x.MAC).IsRequired();  // Campo obrigat�rio
        modelBuilder.Entity<GpsData>().Property(x => x.Latitude).IsRequired();
        modelBuilder.Entity<GpsData>().Property(x => x.Longitude).IsRequired();
        modelBuilder.Entity<GpsData>().Property(x => x.Altitude).IsRequired();
        modelBuilder.Entity<GpsData>().Property(x => x.DataHora).IsRequired();
    }
}

// Classe para os dados de GPS
public class GpsData
{
    public int Id { get; set; }
    public string MAC { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public double Altitude { get; set; }
    public DateTime DataHora { get; set; }
}


public class Device
{
    public int Id { get; set; }

    [JsonProperty("dispositivo")]
    public string Nome { get; set; }

    [JsonProperty("MAC_device")]
    public string Mac { get; set; }

    [JsonProperty("x")]
    public double Latitude { get; set; }

    [JsonProperty("y")]
    public double Longitude { get; set; }

    public string Ultima_Leitura { get; set; } // Adapte conforme necess�rio
}


public class Gateways
{
    [Key] // Define o campo Mac como chave prim�ria
    public string Mac { get; set; } = string.Empty; // Inicializa com uma string vazia para evitar null

    public string Nome { get; set; } = string.Empty; // Inicializa com uma string vazia para evitar null

    public double Latitude { get; set; } = 0; // Inicializa com 0 como valor padr�o
    public double Longitude { get; set; } = 0; // Inicializa com 0 como valor padr�o
}

public class Map
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Imagem { get; set; }


    // Propriedades adicionais para o mapa
    //public double CenterX { get; set; } = 0; // Posi��o central do mapa no eixo X
    //public double CenterY { get; set; } = 0; // Posi��o central do mapa no eixo Y
    //public double ScaleLat { get; set; } = 100; // Escala de latitude do mapa
    //public double ScaleLon { get; set; } = 100; // Escala de longitude do mapa
}


public class RegisteredDevice
{

    [Key] // Define o campo Mac como chave prim�ria
    public string Mac { get; set; }  // Chave prim�ria
    public string Nome { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Sn { get; set; }  // N�mero de s�rie do dispositivo
}









public class GatewayService
{
    private readonly AppDbContext _context;

    public GatewayService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<Gateways>> GetGatewaysAsync()
    {
        return await _context.Gateways.ToListAsync();
    }

    public async Task<Gateways> GetGatewayByMacAsync(string mac)
    {
        return await _context.Gateways.FindAsync(mac);
    }



    public async Task AddGatewayAsync(Gateways gateway)
    {
        if (gateway == null)
        {
            throw new ArgumentNullException(nameof(gateway));
        }

        // Verifica se o gateway j� existe para evitar duplica��es
        var existingGateway = await _context.Gateways.FindAsync(gateway.Mac);
        if (existingGateway != null)
        {
            throw new InvalidOperationException("Gateway com este MAC j� existe.");
        }

        // Adiciona o novo gateway ao contexto do banco de dados
        _context.Gateways.Add(gateway);

        // Tenta salvar as mudan�as no banco de dados
        await _context.SaveChangesAsync();
    }



    public async Task UpdateGatewayAsync(Gateways gateway)
    {
        // Certifica-se de que o gateway existe antes de atualizar
        var existingGateway = await _context.Gateways.FindAsync(gateway.Mac);
        if (existingGateway == null)
        {
            throw new InvalidOperationException("Gateway n�o encontrado para atualiza��o.");
        }

        existingGateway.Nome = gateway.Nome;
        existingGateway.Latitude = gateway.Latitude;
        existingGateway.Longitude = gateway.Longitude;

        _context.Gateways.Update(existingGateway);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteGatewayAsync(string mac)
    {
        var gateway = await _context.Gateways.FindAsync(mac);
        if (gateway != null)
        {
            _context.Gateways.Remove(gateway);
            await _context.SaveChangesAsync();
        }
    }
}


